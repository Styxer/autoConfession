﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mmosoft.Facebook.Sdk.Utilities
{
    public class FacebookClientErrors
    {
        public const string FacebookAccountCollectionEmpty = "Facebook acccount collection is empty.";
        public const string CookieKeyCUserNotFound = "Cookie c_user not found.";
    }
}
